/**
 * lab5_template_extra_help.c
 *
 * Description: This is file is meant for those that would like a little
 *              extra help with formatting their code.
 *
 */



#include "timer.h"
#include "lcd.h"
#include "uart_extra_help.h"
#include "resetSimulation.h"

// Adding global volatile varibles for communcating between 
// your Interupt Service Routine, and your non-interupt code.

volatile  char uart_data;  // Your UART interupt code can place read data here
volatile  char flag;       // Your UART interupt can update this flag
                           // to indicate that it has placed new data
                           // in uart_data                     
int i=0;
char uartData=0;
char buf[21];


void main()
{
    //resetSimulationBoard();
    timer_init();
    lcd_init();
    uart_init(115200);
    lcd_printf("initialized");
    /*for(i=0;i<20;i++){
        buf[i]=' ';
    }
    buf[20]='\n';*/
    i=0;
    flag=0;
    while(1){
        if(flag){
            lcd_printf("%c",uart_data);
            if(uart_data=='\r'){
                uart_sendChar('\n');
            }
            else{
                uart_sendChar(uart_data);
            }
            flag=0;
        }




        //code for part 2
        /*uartData=uart_receive();
        if(uartData=='\r'){
            uart_sendChar('\n');
        }
        else{
            uart_sendChar(uartData);
        }*/


        //code for part 1
        /*for(i=0;i<20;i++){
            buf[i]=' ';
        }
        i=0;
        while(i<20){
            uartData=uart_receive();
            if(uartData=='\r'){
                i=20;
            }
            else{
                lcd_printf("%d",i+1);
                buf[i]=uartData;
            }
            i++;
        }
        lcd_printf("%s",buf);
        i=0;*/
    }
}

