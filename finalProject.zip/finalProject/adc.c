/*
 * adc.c
 *
 *  Created on: Oct 6, 2020
 *      Author: nsmoser
 */

#include "adc.h"
//#include "open_interface.h"
#include <math.h>
#include <stdio.h>

void adc_init(){
    //GPIO initialization: Pin B4 / AIN10
    SYSCTL_RCGCGPIO_R |= 0x2;
    SYSCTL_RCGCADC_R |= 0x1;
    GPIO_PORTB_AFSEL_R |= 0x10;
    GPIO_PORTB_DEN_R &= 0xEF;
    GPIO_PORTB_DIR_R &= 0xEF;
    GPIO_PORTB_AMSEL_R |=0x10;
    GPIO_PORTB_ADCCTL_R |=0x10;

    //ADC initialization: Sample Sequencer 0 & ADC0
    ADC0_ACTSS_R &= 0xE;
    ADC0_EMUX_R = 0x0000;
    ADC0_SSMUX0_R |= 0xA;
    ADC0_SSCTL0_R |= 0x6;
    ADC0_SAC_R |= 0x6;      //sample averaged x64
    ADC0_ACTSS_R |= 0x1;
/*    oi_t *sensor_data = oi_alloc();
    oi_init(sensor_data);
    oi_setWheels(0,0);*/
}

float getDist(int reading){
    float power = -1.163,constant = 118455.0;
    float dist = (pow((float)reading,power));
    dist=((dist)*constant);
    return dist;
}

int adc_read(){           //takes in char array for purposes
    int reading=0;float dist=0;     //of lab 7, can be changed
    ADC0_PSSI_R=0x1;                //start sample sequencing
    while((ADC0_RIS_R&0x1)==0){}    //wait for data in fifo
    reading=ADC0_SSFIFO0_R;         //get reading from fifo
    dist=getDist(reading);


    //sprintf(data, "\r%d\t\t\t%f\r\n", reading, dist);
    return (int)reading;                    //return measured distance
}

/*void adc_calibrate(){
    double distance=0;
    int reading=0,i=0,left=0,right=0;
    char distanceData[] = "\rDistance (cm)\t\tIR Reading\t\tLast Calibration\r\n";
    oi_t *sensor_data = oi_alloc();
    oi_init(sensor_data);
    uart_sendStr(distanceData);
    oi_setWheels(250,250);
    while((left+right)==0){
        oi_update(sensor_data);
        left=sensor_data->bumpLeft;
        right=sensor_data->bumpRight;
    }
    oi_setWheels(0,0);
    for(i=5;i<55;i+=5){
        oi_setWheels(-200,-200);
        while(distance<=50){
            oi_update(sensor_data);
            distance-=sensor_data->distance;
        }
        oi_setWheels(0,0);
        ADC0_PSSI_R=0x1;
        while((ADC0_RIS_R&0x1)==0){}
        reading=ADC0_SSFIFO0_R;
        distance=getDist(reading);
        sprintf(distanceData, "\r%d\t\t\t%d\t\t\t%f\r\n", i,reading,distance);
        distance=0;
        uart_sendStr(distanceData);
        timer_waitMillis(500);
    }
}*/
