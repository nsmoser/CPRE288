/*
 * scan.h
 *
 *  Created on: Oct 28, 2020
 *      Author: nsmoser
 */

#ifndef SCAN_H_
#define SCAN_H_

#include "adc.h"
#include "ping.h"
#include "servo.h"

typedef struct{
    float pingDist;
    int irDist;
}objectScan;

void getScan(objectScan *scanData, float angle);



#endif /* SCAN_H_ */
