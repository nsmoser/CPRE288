/*
 * scan.h
 *
 *  Created on: Oct 28, 2020
 *      Author: nsmoser
 */

#ifndef SCAN_H_
#define SCAN_H_

#include "adc.h"
#include "ping.h"
#include "servo.h"
#include "uart_extra_help.h"
#include <math.h>

typedef struct{     //used to gather field information
    float pingDist; //ping sensor reading
    int irDist;     //ir sensor reading
    char obj;       //flag that is used to identify positions with objects
}field_t;

typedef struct{    //metadata for triangular object position
    float aSide;   //distance measurement, hypotenuse
    float bSide;   //"opposite" side
    float cSide;   //"adjacent" side
    float bAngle;  //angle between c and a
    float cAngle;  //angle between a and b
}triangle_t;       //angle between b and c is 90 degrees, didnt bother to include

typedef struct{     //information describing an object
    int position;   //angle relative to the cybot
    float dist;     //linear distance from the cybot
    float width;    //width of the object
    triangle_t triangle;//triangle metadata to find location after linear movement
}object_t;

extern volatile char uart_flag;
extern volatile char uart_data;

void getScan(field_t *scanData, float angle);
//used to get scan data from sensors

void getField(field_t *field, char *stringPrint);
//used to get field data

float widthCalc(float startAngle, float endAngle, float dist);
//used to calculate width of objects

int getObj(field_t *field, object_t *objects);
//used to find objects in collected field data

void objAdjust(object_t *objects,int *objCount,int *firstObj,char adjustFlat,char *stringPrint);
//used to adjust object location after linear movement

void avoidanceCheck(object_t *objects,int objCount,int firstObj,char *stringPrint);
//used to check if any given object is avoidable by linear movement

void targetCheck(object_t *objects,int objCount,int firstObj,char *stringPrint);
//used to check for target zone based on object width

#endif /* SCAN_H_ */
