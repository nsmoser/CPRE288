/*
 * scan.h
 *
 *  Created on: Oct 28, 2020
 *      Author: nsmoser
 */

#ifndef SCAN_H_
#define SCAN_H_

#include "adc.h"
#include "moveCommands.h"
#include "open_interface.h"
#include "ping.h"
#include "servo.h"
#include <math.h>

typedef struct{
    float pingDist;
    int irDist;
    char obj;
}field_t;

typedef struct{
    int position;
    float dist;
    float width;
}object_t;

void getScan(field_t *scanData, float angle);

void getField(field_t *field, char *stringPrint, oi_t *sensorData);

float widthCalc(float startAngle, float endAngle, float dist);

int getObj(field_t *field, object_t *objects);

#endif /* SCAN_H_ */
