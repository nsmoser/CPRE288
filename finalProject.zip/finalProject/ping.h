/*
 * ping.h
 *
 *  Created on: Oct 12, 2020
 *      Author: nsmoser
 */

#ifndef PING_H_
#define PING_H_

#include <stdint.h>
#include <stdbool.h>
#include <inc/tm4c123gh6pm.h>
#include "driverlib/interrupt.h"
#include <stdio.h>
#include "Timer.h"
#include "adc.h"
//#include "open_interface.h"
#include <String.h>
#include <math.h>

extern volatile char timerStatus;
extern volatile char overflow;
extern volatile int start;
extern volatile int end;

void ping_init();

void timerHandler();

void ping_timer_init();

void ping_send();

float ping_read();

void IR_calibrate();

#endif /* PING_H_ */
