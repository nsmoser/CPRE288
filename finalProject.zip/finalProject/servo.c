/*
 * servo.c
 *
 *  Created on: Oct 19, 2020
 *      Author: nsmoser
 */

#include "servo.h"

unsigned int pulsePeriod = 20*1000*16;
float servoSlope = -23000.0/180.0;
//20ms to us to clock cycles

void servo_init(){
    //gpio setup
    SYSCTL_RCGCGPIO_R   |=  0x2;
    //enable clock to port b
    GPIO_PORTB_AFSEL_R  |=  0x20;
    //alternate function pb5
    GPIO_PORTB_DEN_R    |=  0x20;
    //enable digital on pb5
    GPIO_PORTB_DIR_R    |=  0x20;
    //enable output on pb5
    GPIO_PORTB_PCTL_R   |=  0x700000;
    //select timer 1b on port b5

    //timer setup
    SYSCTL_RCGCTIMER_R  |=  0x2;
    //enable clock to timer 1
    TIMER1_CTL_R        &=  0xEFF;
    //disable timer 1 for configuration
    TIMER1_CFG_R        =   0x4;
    //config specified in datasheet
    TIMER1_TBMR_R       =   0xA;
    //config specified for pwm in datasheet
    TIMER1_TBILR_R      =   (pulsePeriod & 0xFFFF);
    //timer preload specified by presentation
    TIMER1_TBPR_R       =   (pulsePeriod >> 16);
    //timer prescalar specified by presentation
    TIMER1_TBMATCHR_R   =   ((pulsePeriod-9000) & 0xFFFF);
    TIMER1_TBPMR_R      =   ((pulsePeriod-9000) >> 16);
    //timer match value
    //calibrated such that 32000=0, 1650=90, and 9000=180
    //slope = -23000/180 = -127.777777
    TIMER1_CTL_R        |=  0x100;
    //restart timer
}

int servo_move(float degree){
    int pos=0;
    pos = 32000 + (degree * servoSlope);
    //pos = b + mx
    //b is determined by finding pwm needed for 0
    //m is determined by finding pwm needed for 0 and 180 degrees
    TIMER1_TBMATCHR_R   =  ((pulsePeriod-pos) & 0xFFFF);
    TIMER1_TBPMR_R      =  ((pulsePeriod-pos) >> 16);
    timer_waitMillis(100);
    return pos;
}
