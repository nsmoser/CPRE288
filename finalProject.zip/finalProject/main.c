/**
 * main.c
 */

#include "adc.h"
#include "lcd.h"
#include "moveCommands.h"
#include "open_interface.h"
#include "ping.h"
#include "scan.h"
#include "servo.h"
#include "Timer.h"
#include "uart_extra_help.h"

volatile char overflow;
volatile char timerStatus;
volatile char flag;
volatile char uart_data;
volatile int start;
volatile int end;

int i=0,objCount=0;
char stringPrint[]="\rObject\t\tposition\t\twidth\r\n";
object_t field[180];
object_t *fieldPointer = field;

int main(void)
{
    timer_init();
    adc_init();
    lcd_init();
    oi_t *sensorData = oi_alloc();
    oi_init(sensorData);
    ping_init();
    servo_init();
    servo_move(90);
    uart_init(115200);
    while(1){
        if(flag){
            objCount=objScan(fieldPointer,stringPrint);
            uart_sendStr(stringPrint);
            for(i=0;i<objCount;i++){
                sprintf(stringPrint,"%d %d %f",i+1,field[i].position,field[i].width);
                uart_sendStr(stringPrint);
            }
            flag=0;
        }
    }
	return 0;
}
