/**
 * main.c
 */

#include "adc.h"
#include "button.h"
#include "lcd.h"
#include <math.h>
#include "moveCommands.h"
#include "open_interface.h"
#include "ping.h"
#include "scan.h"
#include "servo.h"
#include "Timer.h"
#include "uart_extra_help.h"

volatile char overflow;
volatile char timerStatus;
volatile int start;
volatile int end;
//timer variables that can be manipulated by interrupts

volatile char uart_flag;
volatile char uart_data;
//uart variables that can be manipulated by interrupts

volatile int button_flag;
volatile int button_num;
//button variables that can be manipulated by interrupts

int i=0,objCount=0,firstObj=0;
//i is used if incrementing is needed, objCount is the number of objects
//firstObj is used for adjusting starting point of objects array if first object
//becomes out of range of the robot

char stringPrint[]="this string is way too long so that it can acclimate any sized string";
//longest possible string needed for stringPrint, used anytime uart comm is needed

char divider[]="\r------------------------------------------------\r\n";
//used for formatting uart output. Makes it prettier on putty since we dont have a socket

char deliveryMode=0,adjustFlag=0,rescanFlag=0;
//flags that are to be used. chars to save memory

field_t field[180];
//array of field structs, can see a whole 180 field in front of the cybot

object_t objects[10];
//array of objects, 10 objects max anticipated but it can be enlarged

int main(void)
{
    timer_init();                           //initialization steps
    adc_init();
    button_init();
    lcd_init();
    lcd_printf("press 1 for delivery");
    oi_t *sensorData = oi_alloc();
    oi_init(sensorData);
    ping_init();
    servo_init();
    servo_move(90);
    uart_init(115200);
    while(1){
        if(button_flag){                    //if a button is pressed
            if(button_num=='1'){            //if the button is the delivery button
                lcd_printf("Delivering");   //print delivering on the lcd
                deliveryMode=1;             //put bot in delivery mode
                sprintf(stringPrint,"\rPlease perform initial scan");
                uart_sendStr(divider);
                timer_waitMillis(10);
                uart_sendStr(stringPrint);
                sprintf(stringPrint,"\rOr don't, if you're dangerous\r\n");
                uart_sendStr(stringPrint);
            }

            else if(button_num=='2'){       //if the button is the delivered button
                lcd_printf("Delivered");    //print delivered to the lcd screen
                deliveryMode=0;             //disable delivery mode
            }
            button_flag=0;
        }
        if(uart_flag){                      //if the bot receives a uart command
            if(deliveryMode){               //if the bot is in delivery mode
                uart_sendStr(divider);
                driveHandler(field,objects,stringPrint,sensorData,&objCount,&adjustFlag,&rescanFlag);
                /* driveHandler function handles basic driving functionality. move forward,backward,turn left,turn right
                 * also handles scanning for objects when x key is pressed.
                 * turned into its own function to clean up main. driveHandler located in moveCommands.c*/

                if(adjustFlag>=1){          //if the bot moves forwards or backwards linearly
                    objAdjust(objects,&objCount,&firstObj,adjustFlag,stringPrint);
                    avoidanceCheck(objects,objCount,firstObj,stringPrint);//checks if objects can be avoided by the bot
                    targetCheck(objects,objCount,firstObj,stringPrint);
                    adjustFlag=0;           //objAdjust uses triangles to adjust location of objects
                }

                if(rescanFlag>=4){              //if a rescan is needed
                    sprintf(stringPrint,"\rPlease rescan field!\r\n");
                    uart_sendStr(stringPrint);  //prompt user to rescan, but dont force it
                    sprintf(stringPrint,"\rOr don't, if you're dangerous\r\n");
                    uart_sendStr(stringPrint);  //if they want to fuck up the bot, let em
                }
                /* note: do not force a rescan. it takes forever, so if the user doesn't want to rescan, who cares
                 * plus, i ran into this weird issue where if i made the bot take any sort of action other than what
                 * is written above, the bot would shoot south off the screen fast AF. idk why, but it doesn't do
                 * it with this rescan setup, so im not touching it.
                 */
                rescanFlag++;                   //increment the rescan flag
            }

            else{                           //if the bot is not in delivery mode, do not allow movement
                sprintf(stringPrint,"\rBot not in delivery mode\r\n");
                uart_sendStr(divider);
                uart_sendStr(stringPrint);
            }
            uart_flag=0;
        }
    }
}
