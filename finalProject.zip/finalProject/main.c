/**
 * main.c
 */

#include "adc.h"
#include "lcd.h"
#include "moveCommands.h"
#include "open_interface.h"
#include "ping.h"
#include "scan.h"
#include "servo.h"
#include "Timer.h"
#include "uart_extra_help.h"

volatile char overflow;
volatile char timerStatus;
volatile char flag;
volatile char uart_data;
volatile int start;
volatile int end;

int i=0;
char stringPrint[]="\rAngle\t\tIR\t\tPing\r\n";
objectScan field[180];
objectScan *fieldPointer = field;

int main(void)
{
    timer_init();
    adc_init();
    lcd_init();
    oi_t *sensorData = oi_alloc();
    oi_init(sensorData);
    ping_init();
    servo_init();
    servo_move(90);
    uart_init(115200);
    while(1){
        if(flag){
            for(i=0;i<=180;i++){
                getScan(fieldPointer,(float)i);
                if(field[i].irDist>200){
                    sprintf(stringPrint,"\r%d\t\t%f\r\n",i,field[i].pingDist);
                }
                else{
                    sprintf(stringPrint,"\r%d\t\tNo Object\r\n",i);
                }
                uart_sendStr(stringPrint);
                fieldPointer++;
            }
            flag=0;
        }
    }
	return 0;
}
