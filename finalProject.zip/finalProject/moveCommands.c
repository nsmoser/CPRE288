/*
 * move_commands.c
 *
 *  Created on: Sep 2, 2020
 *      Author: nsmoser
 *
 *      see moveCommands.h for usage instructions
 *
 * NOTE: 5 degrees is subtracted from angle argument for while loop used in turnClockwise.
 * Robot seems to overshoot the angle argument every time, and this is the perfect angle
 * correction for this turn speed. Angle correction will need adjusted with speed adjustment.
 * Angle correction distance was determined with guess and check, so good luck.
 *
*/
#include "moveCommands.h"



void moveForward(oi_t *sensor, int cm, char *stringPrint){            //forward movement function
    double distance=0;                             //distance variable, must be double
                                                   //since sensor distance is a double
    oi_setWheels(200,200);                         //move forward at moderate speed
    while(distance<(cm*10)){                       //while measured distance is less than
                                                   //distance argument
        oi_update(sensor);                         //update sensor data struct
        if(sensor->bumpLeft){                      //if the bot is bumped on the left side
            sprintf(stringPrint,"\rOpe! Left side bumped\r\n");
            uart_sendStr(stringPrint);             //tell user it bumped on left side & went back 5cm
            sprintf(stringPrint,"\rMoving Backwards 5cm\r\n");
            uart_sendStr(stringPrint);
            moveBackward(sensor,5);                //drive bot back 5cm
            uart_flag=0;
            sprintf(stringPrint,"\rPress any key to acknowledge\r\n");
            uart_sendStr(stringPrint);             //makes sure user acknowledges they hit something
            timer_waitMillis(1000);
            while(!uart_flag){}
            uart_flag=0;
            sprintf(stringPrint,"\rObject Acknowledged\r\n");
            uart_sendStr(stringPrint);
            distance=69420;                        //set distance super high to escape loop
        }                                          //chosen arbitrarily, bc cm=69420 likely wont happen & numbers are funny lmao

        if(sensor->bumpRight){                     //if the bot is bumped on the right side
            sprintf(stringPrint,"\rOpe! Right side bumped\r\n");
            uart_sendStr(stringPrint);             //tell user it bumped on left side & went back 5cm
            sprintf(stringPrint,"\rMoving Backwards 5cm\r\n");
            uart_sendStr(stringPrint);
            moveBackward(sensor,5);                //drive bot back 5cm
            uart_flag=0;
            sprintf(stringPrint,"\rPress any key to acknowledge\r\n");
            uart_sendStr(stringPrint);             //makes sure user acknowledges they hit something
            timer_waitMillis(1000);
            while(!uart_flag){}
            uart_flag=0;
            sprintf(stringPrint,"\rObject Acknowledged\r\n");
            uart_sendStr(stringPrint);
            distance=69420;                        //impossibly high distance again, 69420 lmao
        }

        if((sensor->cliffFrontLeft)||(sensor->cliffLeft)){
            sprintf(stringPrint,"\rOpe! Cliff on the left side\r\n");
            uart_sendStr(stringPrint);             //tell user cliff left side & went back 5cm
            sprintf(stringPrint,"\rMoving Backwards 5cm\r\n");
            uart_sendStr(stringPrint);
            moveBackward(sensor,5);                //drive bot back 5cm
            uart_flag=0;
            sprintf(stringPrint,"\rPress any key to acknowledge\r\n");
            uart_sendStr(stringPrint);             //makes sure user acknowledges they hit something
            timer_waitMillis(1000);
            while(!uart_flag){}
            uart_flag=0;
            sprintf(stringPrint,"\rCliff Acknowledged\r\n");
            uart_sendStr(stringPrint);
            distance=69420;                        //impossibly high distance again, 69420 lmao
        }

        if((sensor->cliffFrontRight)||(sensor->cliffRight)){
            sprintf(stringPrint,"\rOpe! Cliff on the right side\r\n");
            uart_sendStr(stringPrint);             //tell user cliff on right side & went back 5cm
            sprintf(stringPrint,"\rMoving Backwards 5cm\r\n");
            uart_sendStr(stringPrint);
            moveBackward(sensor,5);                //drive bot back 5cm
            uart_flag=0;
            sprintf(stringPrint,"\rPress any key to acknowledge\r\n");
            uart_sendStr(stringPrint);             //makes sure user acknowledges they hit something
            timer_waitMillis(1000);
            while(!uart_flag){}
            uart_flag=0;
            sprintf(stringPrint,"\rCliff Acknowledged\r\n");
            uart_sendStr(stringPrint);
            distance=69420;                        //impossibly high distance again, 69420 lmao
        }

        distance+=sensor->distance;                //add change in distance to
    }                                              //measured distance
    oi_setWheels(0,0);                             //turn off wheels
}

void moveBackward(oi_t *sensor, int cm){           //backwards movement function
    double distance=0;                             //distance variable, must be double
    oi_setWheels(-200,-200);                       //move backwards at moderate speed
    while(distance<(cm*10)){                       //while measured distance is less than
                                                   //distance argument
        oi_update(sensor);                         //update sensor struct
        distance-=sensor->distance;                //"add" change in distance to
    }                                              //measured distance. Subtracts bc
                                                   //change in distance is negative
    oi_setWheels(0,0);                             //turn off wheels
}

void turnCW(oi_t *sensor, int degrees){            //clockwise turn function
    double angle=0;                                //angle variable, must be double
                                                   //since sensor angle is double
    oi_setWheels(100,-100);                        //move left forward and right backward
                                                   //turns slow to avoid turning too far
    while(angle<(degrees)){                        //while measured angle is less than
     /*adjust subtraction for application*/        //angle argument
        oi_update(sensor);                         //update sensor data struct
        angle+=sensor->angle;                      //add change in angle to
    }                                              //measured angle
    oi_setWheels(0,0);                             //turn off wheels
}

void turnCCW(oi_t *sensor, int degrees){           //counter-clockwise turn function
    double angle=0;                                //angle variable, must be double
    oi_setWheels(-100,100);                        //move right forward and left backwards
    while(angle<(degrees)){                        //while measured angle is less than
        /*adjust subtraction for application*/     //angle argument
        oi_update(sensor);                         //update sensor data struct
        angle-=sensor->angle;                      //"add" change in angle to measured
    }                                              //angle. Subtracts bc change in angle
                                                   //is negative in this situation
    oi_setWheels(0,0);                             //turn off wheels
}

void driveHandler(field_t *field, object_t *objects, char *stringPrint, oi_t *sensorData, int *objCount, char *adjustFlag,char *rescanFlag){
    int i=0;

    if(uart_data=='x'){         //if the bot receives the scan command
        /*  the following lines do a 180 scan in front of the robot when a scan is triggered.
         *  after scanning, the command reports the objects positions and widths to the uart
        */
        getField(field,stringPrint);                //get field, pretty self explanatory
        *objCount=getObj(field,objects);            //find objects in the field, return a count of the objects
        sprintf(stringPrint,"\rObject\t\tposition\twidth\t\tdistance\r\n");
        uart_sendStr(stringPrint);
        timer_waitMillis(50);                       //stopped working, this fixed it, idk why
        for(i=0;i<*objCount;i++){                   //print the information about the objects
            sprintf(stringPrint,"\r%d\t\t%d\t\t%f\t%f\r\n",i+1,objects[i].position,objects[i].width,objects[i].dist);
            uart_sendStr(stringPrint);
        }
        timer_waitMillis(100);                      //uart_sendStr stopped working, this fixes it, idk why
        *adjustFlag=0;                              //no adjustment needed after a scan
        *rescanFlag=0;                              //no rescan needed after a scan
    }

    else if(uart_data=='w'){    //if the user wants to move forward
        sprintf(stringPrint,"\rMoving forward 5cm\r\n");
        uart_sendStr(stringPrint);
        moveForward(sensorData,5,stringPrint);      //move the bot forwards 5cm
        *adjustFlag=1;                              //flag a forward adjustment
    }

    else if(uart_data=='s'){    //if the user wants to move backwards
        sprintf(stringPrint,"\rMoving backwards 5cm\r\n");
        uart_sendStr(stringPrint);
        moveBackward(sensorData,5);                 //move the bot backwards 5cm
        *adjustFlag=2;                              //flag a backwards adjustment
    }

    else if(uart_data=='a'){    //if the user wants to turn left
        sprintf(stringPrint,"\rTurning to the left 5 degrees\r\n");
        uart_sendStr(stringPrint);
        turnCCW(sensorData,5);                      //rotate 5 degrees to the right
        *adjustFlag=0;                              //no adjustment possible because idk how
        *rescanFlag=4;                              //notify a rescan is necessary since no adjustment
    }

    else if(uart_data=='d'){    //if the user wants to turn right
        sprintf(stringPrint,"\rTurning to the right 5 degrees\r\n");
        uart_sendStr(stringPrint);
        turnCW(sensorData,5);                       //rotate 5 degrees to the left
        *adjustFlag=0;                              //no adjustment possible because idk how
        *rescanFlag=4;                              //notify a rescan is necessary since no adjustment
    }

    else{                       //if the user does not press a valid key, inform them through uart
        sprintf(stringPrint,"\rPlease send a valid command\r\n");
        uart_sendStr(stringPrint);
        *adjustFlag=0;                              //no adjustment needed, no movement
    }
}
