/*
 * scan.c
 *
 *  Created on: Oct 28, 2020
 *      Author: nsmoser
 */
#include "scan.h"

void getScan(objectScan *scanData, float angle){
    int servoStatus = servo_move(angle);
    scanData -> pingDist = ping_read();
    scanData -> irDist = adc_read();
}


