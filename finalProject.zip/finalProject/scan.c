/*
 * scan.c
 *
 *  Created on: Oct 28, 2020
 *      Author: nsmoser
 */
#include "scan.h"

void getScan(field_t *scanData, float angle){
    int servoStatus = servo_move(angle);
    scanData -> pingDist = ping_read();
    scanData -> irDist = adc_read();
}

void getField(field_t *field, char *stringPrint, oi_t *sensorData){
    int angle=0,prevIrDist;
    sprintf(stringPrint, "\rAngle\t\tPING distance\t\tIR raw value\r\n");
    uart_sendStr(stringPrint);
    for(angle=0;angle<=180;angle++){                    //begin scanning between 0 and 180
        getScan(field,angle);                           //gets sensor data
        if(field->irDist>200){                          //if it sees an object
            field->obj=1;                               //set the object flag
        }
        else{                                           //if it doesnt see an object
            field->obj=0;                               //dont set the object flag
        }
        sprintf(stringPrint, "\r%d\t\t%f\t\t%d\r\n",angle,field->pingDist,field->irDist);
        uart_sendStr(stringPrint);
        field++;
    }
    turnCCW(sensorData,180);
    for(angle=180;angle<=360;angle++){                    //begin scanning between 0 and 180
        getScan(field,angle-180);                           //gets sensor data
        if(field->irDist>200){                          //if it sees an object
            field->obj=1;                               //set the object flag
        }
        else{                                           //if it doesnt see an object
            field->obj=0;
        }
        sprintf(stringPrint, "\r%d\t\t%f\t\t%d\r\n",angle,field->pingDist,field->irDist);
        uart_sendStr(stringPrint);
        field++;
    }
}

float widthCalc(float startAngle, float endAngle, float dist){
    float width=0,topAngle=0,bottomAngle=0;        //create new width, top angle, and bottom angle
    float rad=((22.0/7.0)/180.0);                  //radian conversion for sine functions
    topAngle=(endAngle-startAngle)/2.0;            //top angle is the width of the scan divided by 2
    bottomAngle=(90.0-topAngle);                     //bottom angle is 180-right angle-top angle
    width=((sin(topAngle*rad))/(sin(bottomAngle*rad)))*dist;    //width is ratio of sines multiplied by distance
    width=width*2.0;                               //double width so it is entire object and not just half
    return width;                                  //return the width

}

int getObj(field_t *field, object_t *objects){
    int angle=0,startAngle=0,endAngle=0,objCount=0,objFlag=0;
    float distAvg=0;
    for(angle=0;angle<360;angle++){                         //work through entire 360 field
        if(field->obj==1){                                  //if first flagged angle
            startAngle=angle;                               //set as start angle
        }
        while(field->obj==1){                               //while object flag is set
            distAvg+=field->pingDist;                       //sum distance to average
            field++;                                        //increment field pointer
            angle++;                                        //increment angle
            objFlag=1;                                      //tick object flag
        }
        if(startAngle==angle-1){
            objFlag=0;
        }
        if(objFlag){                                        //occurs when object flag is 0
            endAngle=angle;                                 //set end angle
            objects->position = angle-((endAngle-startAngle)/2);//do math to determine position
            objects->dist = (distAvg/(endAngle-startAngle));    //do math to find distance from bot
            objects->width = widthCalc(startAngle,endAngle,objects->dist);//calculate width
            objCount++;objects++;objFlag=0;distAvg=0;       //increment object count, object pointer, disable flag, reset distance average
            startAngle=0;endAngle=0;
        }
        field++;//increment field pointer
    }
    return objCount;
}
