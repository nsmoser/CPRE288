/*
 * scan.c
 *
 *  Created on: Oct 28, 2020
 *      Author: nsmoser
 */
#include "scan.h"

void getScan(field_t *scanData, float angle){
    int servoStatus = servo_move(angle);                //move the servo to the degree specified
    scanData -> pingDist = ping_read();                 //get distance from the ping sensor
    scanData -> irDist = adc_read();                    //get reading from the ir sensor
}

void getField(field_t *field, char *stringPrint){
    /* note: the getField function was partially built to accomodate for dropped ir readings
     * this means that it will overstate the angular width of anything it sees. any object
     * seeking algorithm will need to accommodate for that*/
    int angle=0,prevIrDist=0;
    sprintf(stringPrint, "\rPerforming scan...\r\n");
    uart_sendStr(stringPrint);
    for(angle=0;angle<=180;angle++){                    //begin scanning between 0 and 180
        getScan(field,angle);                           //gets sensor data
        if((field->irDist>200)||(prevIrDist>200)){      //if it sees an object or there was an object on the previous scan
            field->obj=1;                               //set the object flag
        }
        else{                                           //if it doesnt see an object
            field->obj=0;                               //dont set the object flag
        }
        prevIrDist=field->irDist;                       //record current ir as previous ir, meant to accommodate noise
        field++;
    }
}

float widthCalc(float startAngle, float endAngle, float dist){
    float width=0,topAngle=0,bottomAngle=0;        //create new width, top angle, and bottom angle
    float rad=((22.0/7.0)/180.0);                  //radian conversion for sine functions
    topAngle=(endAngle-startAngle)/2.0;            //top angle is the width of the scan divided by 2
    bottomAngle=(90.0-topAngle);                     //bottom angle is 180-right angle-top angle
    width=((sin(topAngle*rad))/(sin(bottomAngle*rad)))*dist;    //width is ratio of sines multiplied by distance
    width=width*2.0;                               //double width so it is entire object and not just half
    return width;                                  //return the width

}

int getObj(field_t *field, object_t *objects){
    int angle=0,startAngle=0,endAngle=0,objCount=0,objFlag=0;
    float distAvg=0, rad=((22.0/7.0)/180.0);                //needs rad for the stupid triangles
    for(angle=0;angle<180;angle++){                         //work through entire field
        if(field->obj==1){                                  //if first flagged angle
            startAngle=angle;                               //set as start angle
        }                                                   //will then proceed into an active while loop
        while(field->obj==1){                               //while object flag is set
            distAvg+=field->pingDist;                       //sum distance to average
            field++;                                        //increment field pointer
            angle++;                                        //increment angle
            objFlag=1;                                      //tick objFlag
        }                                                   //objFlag determines if object calculations will occur
        if(startAngle==angle-2){                            //meant to check for noise, if a random noise reading comes in
            objFlag=0;                                      //it registers as 2 degrees wide, so if it sees something w/
        }                                                   //that width, it won't do any object size calculations
        if(objFlag){                                        //occurs when object flag is 0
            endAngle=angle-2;                               //set end angle
            objects->position = angle-((endAngle-startAngle)/2);//do math to determine position
            objects->dist = (distAvg/((endAngle-startAngle)+2));//do math to find distance from bot
            objects->width = widthCalc(startAngle,endAngle,objects->dist);//calculate width
            /* Next few lines populate the triangle struct within the objects struct. used to triangulate distance
             * see scan.h for description of sides and angles
             */
            objects->triangle.aSide = objects->dist;        //next few lines use law of sines to establish position triangle
            if(objects->position<90){                       //cAngle is angle between front of bot & object position
                objects->triangle.cAngle = 90.0 - (objects->position);
            }
            else if(objects->position>90){
                objects->triangle.cAngle = (objects->position) - 90.0;
            }
            objects->triangle.bAngle = 90.0 - (objects->triangle.cAngle);//bAngle is last remaining angle
            objects->triangle.bSide = (objects->triangle.aSide)*sin((objects->triangle.bAngle)*rad);//law of sines for bside
            objects->triangle.cSide = (objects->triangle.aSide)*sin((objects->triangle.cAngle)*rad);//law of sines for cside
            objCount++;objects++;objFlag=0;distAvg=0;       //increment object count, object pointer, disable flag, reset distance average
            startAngle=0;endAngle=0;
        }
        field++;//increment field pointer
    }
    return objCount;
}

void objAdjust(object_t *objects,int *objCount,int *firstObj,char adjustFlag,char *stringPrint){
    int i=0;
    float rad = ((22.0/7.0)/180.0);         //make a radian bc sin function only uses radians
    for(i=0;i<*firstObj;i++){               //adjust starting point of iteration in case
        objects++;                          //first object becomes out of range
    }
    for(i=0;i<*objCount;i++){               //run thru objects
        if(adjustFlag==1){                  //if the bot moved forwards
            objects->triangle.bSide-=5;     //subtract 5cm from the bside of the triangle
        }
        else if(adjustFlag==2){             //if the bot moved backward
            objects->triangle.bSide+=5;     //add 5cm to the bside of the triangle
        }
        if(objects->triangle.bSide<0){      //if the bside is negative (bot moved past object)
            *objCount=*objCount-1;          //decrement the object count
            if(!i){                         //if this is the first iteration
                *firstObj=*firstObj+1;      //move the starting point of object to next object
            }
            objects++;i--;                  //increment object pointer, redo iteration
            continue;                       //skip triangulating this object
        }
        if(i==0){                           //print info on first iteration
            sprintf(stringPrint,"\rObject\t\tposition\twidth\t\tdistance\r\n");
            uart_sendStr(stringPrint);
        }
        /* following algorithm finds new dist using a side as hypotenuse for pythagorean theorem
         * cside doesnt change with linear movement and bside increases/decreases by moved distance
         * calculates c-angle using law of sines and converts to degrees and assigns new position
         * other sides & angles aren't used for readjustment, so they aren't used in this
         */
        objects->triangle.aSide = sqrt(pow(objects->triangle.bSide,2)+pow(objects->triangle.cSide,2));
        objects->dist=objects->triangle.aSide;
        objects->triangle.cAngle = (asin((objects->triangle.cSide)/(objects->triangle.aSide)))*(1.0/rad);
        if(objects->position<90){
            objects->position = 90 - objects->triangle.cAngle;
        }
        else if(objects->position>90){
            objects->position = 90 + objects->triangle.cAngle;
        }
        sprintf(stringPrint,"\r%d\t\t%d\t\t%f\t%f\r\n",i+1,objects->position,objects->width,objects->dist);
        uart_sendStr(stringPrint);
        objects++;
    }
}

void avoidanceCheck(object_t *objects,int objCount,int firstObj,char *stringPrint){
    int i=0;
    for(i=0;i<firstObj;i++){
        objects++;
    }
    for(i=0;i<objCount;i++){                    //run through objects
        if(objects->triangle.cSide>17.35){      //if cside is longer than half the width of the robot
            sprintf(stringPrint,"\rObject %d is avoidable\r\n",i+1);
        }                                       //object is avoidable
        else{                                   //otherwise, object isnt avoidable
            sprintf(stringPrint,"\rObject %d isn't avoidable\r\n",i+1);
        }
        uart_sendStr(stringPrint);
        if(objects->dist<15){                   //if the object is close enough (>15cm)
            sprintf(stringPrint,"\rObect %d is less than 15cm away\r\n",i+1);
            uart_sendStr(stringPrint);          //tell the user they are CLOSE to an object
        }
        objects++;

    }
}

void targetCheck(object_t *objects,int objCount,int firstObj,char *stringPrint){
    int i=0;
    for(i=0;i<firstObj;i++){
        objects++;
    }
    for(i=0;i<objCount;i++){
        if(objects->width<=5.5){
            sprintf(stringPrint,"\rObject %d could be an endpoint\r\n",i+1);
            uart_sendStr(stringPrint);
        }
        objects++;
    }
}
