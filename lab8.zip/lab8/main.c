

/**
 * main.c
 */

#include "lcd.h"
#include "ping.h"
#include "uart_extra_help.h"
#include "resetSimulation.h"

volatile char flag;
volatile char uart_data;
volatile char timerStatus;
volatile char overflow;
volatile int start;
volatile int end;

float i=0;
char stringPrint[] = "\rDistance\tClock time\r\n";

int main(void)
{
    //resetSimulationBoard();
    timer_init();
    lcd_init();
    uart_init(115200);
    ping_init();
    adc_init();
    IR_calibrate();
    lcd_printf(stringPrint);
    while(1){
        lcd_printf(" ");
        if(flag){
            i=ping_read();
            sprintf(stringPrint, "%f\t\t%d\r\n", i,start-end);
            uart_sendStr(stringPrint);
            timer_waitMillis(500);
        }
    }
}
