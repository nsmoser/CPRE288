/*
 * ping.c
 *
 *  Created on: Oct 12, 2020
 *      Author: nsmoser
 */

#include "ping.h"

void timerHandler(){
    if(timerStatus==0){     //if rising edge event
        start=TIMER3_TBR_R; //save start time
        timerStatus=1;      //prepare for falling edge
    }
    else if(timerStatus==1){//if falling edge
        end=TIMER3_TBR_R;   //save end time
        timerStatus=2;      //trigger for distance calc
    }
    TIMER3_ICR_R    |=  0x400;
    //clear interrupt
}

void ping_init(){
    overflow=0;
    timerStatus=0;
    //GPIO init. Sets pb3 as output initially
    SYSCTL_RCGCGPIO_R |=    0x2;
    GPIO_PORTB_AFSEL_R &=   0xFF;
    GPIO_PORTB_DEN_R |=     0x8;
    GPIO_PORTB_DIR_R |=     0x8;


    NVIC_EN1_R         |=   0x10;
    //timer 3b = interrupt number 36 -> number 4 in 1
    IntRegister(INT_TIMER3B, timerHandler);
    IntMasterEnable();
    //bind interrupt to handler
}

void ping_timer_init(){
    //timer init. uses timer3
    SYSCTL_RCGCTIMER_R |=   0x8;
    //timer 3 clock enable
    TIMER3_CTL_R       &=   0xEFF;
    //disable timer 3b
    TIMER3_CFG_R       =    0x4;
    //timer config specified in datasheet
    TIMER3_TBMR_R      =    0x07;
    //capture mode, edge-time, count down
    TIMER3_CTL_R       |=   0xC00;
    //positive and negative edge triggered
    TIMER3_TBPR_R      =    0xFF;
    TIMER3_TBILR_R     =    0xFFFF;
    //specified by lab document, workaround for countup
    TIMER3_ICR_R       |=   0x400;
    //clear capture mode event interrupt
    TIMER3_IMR_R       |=   0x400;
    //enable capture mode event interrupt
    TIMER3_CTL_R       |=   0x100;
    //enable timer 3
}

void ping_send(){
    GPIO_PORTB_DATA_R   |=  0x8;
    timer_waitMicros(5);
    GPIO_PORTB_DATA_R   &=  0xF7;
    GPIO_PORTB_DIR_R    &=  0xF7;
    GPIO_PORTB_AFSEL_R  |=  0x8;
    GPIO_PORTB_PCTL_R   |=  0x7000;
}

float ping_read(){
    float pulseWidth=0,dist=0;
    ping_send();            //send a ping, change to input
    ping_timer_init();      //initialize timer 3b
    while(timerStatus!=2){} //wait for edges to be collected
    timerStatus=0;
    //reset timerStatus since edges have been detected
    TIMER3_CTL_R        &=  0xEFF;
    GPIO_PORTB_AFSEL_R  &=  0xF7;
    GPIO_PORTB_DIR_R    |=  0x8;
    //turns timer3b off, resets port b to gpio output
    pulseWidth=start-end;
    if(pulseWidth<0){
        //overflow handler
        pulseWidth=(0xFFFFFF)-end+start;
        overflow++;
        lcd_printf("time overflow %d");
        dist=pulseWidth;
    }
    else{
        dist=pulseWidth;
        lcd_printf("time overflow %d",overflow);
    }
    dist/=16000000.0;   //clock cycles to microseconds to seconds
    dist*=34000.0;      //multiply by speed of sound(34000 cm/s)
    dist/=2.0;          //distance is half trip
    return dist;
}

void IR_calibrate(){
    int pingDist=0,IRdist=0,i=0,left=0,right=0;
    double moveDist=0;
    char stringPrint[]="\rPing reading\tIR reading\r\n";
    oi_t *sensor_data = oi_alloc();
    oi_init(sensor_data);
    uart_sendStr(stringPrint);
    oi_setWheels(250,250);
    while((left+right)==0){
        oi_update(sensor_data);
        left=sensor_data->bumpLeft;
        right=sensor_data->bumpRight;
    }
    oi_setWheels(0,0);
    for(i=5;i<55;i+=5){
        oi_setWheels(-100,-100);
        while(moveDist<=50){
            oi_update(sensor_data);
            moveDist-=sensor_data->distance;
        }
        oi_setWheels(0,0);
        ADC0_PSSI_R=0x1;
        while((ADC0_RIS_R&0x1)==0){}
        IRdist=ADC0_SSFIFO0_R;
        pingDist=ping_read();
        sprintf(stringPrint,"\r%d\t\t%d\r\n",pingDist,IRdist);
        moveDist=0;
        uart_sendStr(stringPrint);
    }
    oi_setWheels(0,0);
}
