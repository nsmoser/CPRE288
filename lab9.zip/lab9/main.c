

/**
 * main.c
 */

#include "lcd.h"
#include "servo.h"
#include "button.h"

float degree = 90;
char direction=0,button=0;
int servoValue=0;
//for direction 0 = ccw, 1 = cw

int main(void)
{
	timer_init();
	lcd_init();
	button_init();
	servo_init();
	servo_move(degree);
	while(1){
	    button=button_getButton();
	    if(button==0){}
	    else if(button==1){
	        if(!direction){
	            degree++;
	        }
	        else if (direction){
	            degree--;
	        }
	    }
	    else if(button==2){
	        if(!direction){
	            degree+=5;
	        }
	        else if(direction){
	            degree-=5;
	        }
	    }
	    else if(button==3){
	        if(!direction){
	            direction=1;
	            timer_waitMillis(100);
	        }
	        else if(direction){
	            direction=0;
	            timer_waitMillis(100);
	        }
	    }
	    else if(button==4){
	        if(!direction){
	            degree=180;
	        }
	        else if(direction){
	            degree=0;
	        }
	    }
	    if(degree>=180){degree=180;}
	    if(degree<=0){degree=0;}
	    servoValue = servo_move(degree);
	    if(!direction){
	        lcd_printf("Move CCW Angle: %d",(int)degree);
	    }
	    else if(direction){
	        lcd_printf("Move CW Angle: %d",(int)degree);
	    }
	    //lcd_printf("%d", servoValue);

	}
}
