/*
 * servo.h
 *
 *  Created on: Oct 19, 2020
 *      Author: nsmoser
 */

#ifndef SERVO_H_
#define SERVO_H_

#include "Timer.h"
#include <stdint.h>
#include <stdbool.h>
#include <inc/tm4c123gh6pm.h>
#include "driverlib/interrupt.h"

void servo_init();

int servo_move(float degrees);

#endif /* SERVO_H_ */
