/*
 * adc.c
 *
 *  Created on: Oct 6, 2020
 *      Author: nsmoser
 */

#include "adc.h"
#include <math.h>
#include <stdio.h>

void adc_init(){
    //GPIO initialization: Pin B4 / AIN10
    SYSCTL_RCGCGPIO_R |= 0x2;
    SYSCTL_RCGCADC_R |= 0x1;
    GPIO_PORTB_AFSEL_R |= 0x10;
    GPIO_PORTB_DEN_R &= 0xEF;
    GPIO_PORTB_DIR_R &= 0xEF;
    GPIO_PORTB_AMSEL_R |=0x10;
    GPIO_PORTB_ADCCTL_R |=0x10;

    //ADC initialization: Sample Sequencer 0 & ADC0
    ADC0_ACTSS_R &= 0xE;
    ADC0_EMUX_R = 0x0000;
    ADC0_SSMUX0_R |= 0xA;
    ADC0_SSCTL0_R |= 0x6;
    ADC0_SAC_R |= 0x6;      //sample averaged x64
    ADC0_ACTSS_R |= 0x1;
}

int adc_read(char *data){           //takes in char array for purposes
    int reading=0;float dist=0;     //of lab 7, can be changed
    ADC0_PSSI_R=0x1;                //start sample sequencing
    while((ADC0_RIS_R&0x1)==0){}    //wait for data in fifo
    reading=ADC0_SSFIFO0_R;         //get reading from fifo
    dist=(pow(reading,-1.163));
    dist=((dist)*(118455.0));
    //lcd_printf("%f",dist);


    sprintf(data, "\r%d\t\t%f\r\n", reading, dist);
    return (int)dist;                    //return measured distance
}
