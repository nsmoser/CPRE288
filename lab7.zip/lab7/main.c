

/**
 * main.c
 */

#include "adc.h"
#include "lcd.h"
#include "Timer.h"
#include "uart_extra_help.h"
#include "resetSimulation.h"

volatile char flag;
volatile char uart_data;
int IR_dist=0;
char data[]="\rDistance (cm)\t\tIR Reading\r\n";

int main(void)
{
    //resetSimulationBoard();
	lcd_init();
	timer_init();
	uart_init(115200);
	adc_init();
	uart_sendStr(data);
	while(1){
	    IR_dist=adc_read(data);
	    lcd_printf("%d",IR_dist);
	    uart_sendStr(data);
	    timer_waitMillis(100);
	}
}
