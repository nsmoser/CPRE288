

/**
 * main.c
 * all commands for movement and object detection are in moveCommands.c and .h
 * uart commands are in uart_extra_help.c and .h
 * timer.h added out of precaution
 * lcd.h added for debut
 * button.h added out of precaution
 * cyBot_Scan.h used for scanning objects
 * open_interface.h needed for movement
 *
 * MAKE SURE TO CALIBRATE SENSOR
 * the scan sensor measurements are about 40 degrees off, so make sure to do a test run
 * to check what compensation should be made to objScan function in moveCommands.c
 * adjustments should be made in order to compensate for a lack of scanning range.
 */
#include "timer.h"
#include "lcd.h"
#include "uart_extra_help.h"
#include "resetSimulation.h"
#include "cyBot_Scan.h"
#include "open_interface.h"
//#include "button.h"
#include "moveCommands.h"
/*
 * all variables that are to be used in the main section are initialized below
 */
volatile char uart_data;
volatile char flag;
int i=0,j=0,angle=0,dist=0,objCount=0,smallObj=0;
float distAvg=0;
char stringPrint[]="\rAngle\t\tPING distance\t\tIR raw value\r\n";
cyBOT_Scan_t scanData;
object_t *object_NW,*object_SW,*object_NE,*object_SE,*objects;  //is a pointer so that malloc can be used

int main(void){
    //resetSimulationBoard();
    timer_init();
    lcd_init();
    uart_init(115200);
    cyBOT_init_Scan();
    oi_t *sensor_data = oi_alloc();
    oi_init(sensor_data);
    while(1){
        while(flag){                                                //waits for character to be received
            object_NW=(object_t*)malloc(5*sizeof(object_t));          //allocates memory for an array of objects
            object_SW=(object_t*)malloc(5*sizeof(object_t));
            object_NE=(object_t*)malloc(5*sizeof(object_t));
            object_SE=(object_t*)malloc(5*sizeof(object_t));
            objects=(object_t*)malloc(5*sizeof(object_t));
            /*if(objects==NULL){                                      //error checker, starts over if memory
                sprintf(stringPrint, "shits fucked, start over");   //isnt allocated
                uart_sendStr(stringPrint);
                flag=0;
            }*/
            if(uart_data=='s'){                                     //if the character received is the scan trigger
                objCount=objScan(object_NE,stringPrint);              //see moveCommands.c for scan algorithm
                turnCW(sensor_data,90);
                while(j<objCount){
                    lcd_printf("%d %d %d",objCount,i,j);
                    objects[i]=object_NE[j];
                    i++;j++;
                }
                j=0;objCount=0;
                objCount=objScan(object_SE,stringPrint);              //see moveCommands.c for scan algorithm
                turnCW(sensor_data,90);
                while(j<objCount){
                    objects[i]=object_SE[j];
                    objects[i].position+=90;
                    lcd_printf("%d %d %d",objCount,i,j);
                    i++;j++;
                }
                j=0;objCount=0;
                objCount=objScan(object_SW,stringPrint);              //see moveCommands.c for scan algorithm
                turnCW(sensor_data,90);
                while(j<objCount){
                    objects[i]=object_SW[j];
                    objects[i].position+=180;
                    lcd_printf("%d %d %d",objCount,i,j);
                    i++;j++;
                }
                j=0;objCount=0;
                objCount=objScan(object_NW,stringPrint);              //see moveCommands.c for scan algorithm
                turnCW(sensor_data,90);
                while(j<objCount){
                    objects[i]=object_NW[j];
                    objects[i].position+=270;
                    i++;j++;
                }
                objCount=i;
                j=0;
                i=0;
            }
            else{
                flag=0;
            }
            sprintf(stringPrint, "\rObject\t\tWidth\t\tPosition\tDistance\r\n");
            uart_sendStr(stringPrint);
            smallObj=0;                     //smallest object is first object by default
            for(i=0;i<objCount;i++){        //work through object array
                if(objects[i].width<objects[smallObj].width){       //if current object is smaller than smallest object
                    smallObj=i;             //smallest object is updated
                }
            }
            i=0;
            for(i=0;i<objCount;i++){      //print list of recorded objects
                sprintf(stringPrint, "\r%d\t\t%f\t%d\t%f\r\n",i+1,objects[i].width,objects[i].position-90,objects[i].dist);
                uart_sendStr(stringPrint);
            }
            i=0;
            sprintf(stringPrint,"\rSmallest object is %d\r\n",smallObj+1);  //print smallest object
            uart_sendStr(stringPrint);
            if(objects[smallObj].position<90){
                turnCCW(sensor_data,(90-(objects[smallObj].position)));
                moveForward(sensor_data,(objects[smallObj].dist)-5);
            }
            else if (objects[smallObj].position>90){
                turnCW(sensor_data,((objects[smallObj].position)-90));
                moveForward(sensor_data,(objects[smallObj].dist)-5);
            }
            else{

            }
            i=0;j=0;objCount=0;
            free(objects);      //free up memory array
            flag=0;             //reset flag from interrupt
        }
    }
}
