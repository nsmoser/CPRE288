

/**
 * main.c
 */
#include "timer.h"
#include "lcd.h"
#include "uart_extra_help.h"
#include "resetSimulation.h"
#include "cyBot_Scan.h"
#include "open_interface.h"
#include "button.h"
#include "moveCommands.h"

volatile char uart_data;
volatile char flag;
int i=0,j=0,angle=0,dist=0,objCount=0,startAngle=0,endAngle=0,smallObj=0;
float distAvg=0;
char stringPrint[]="\rAngle\t\tPING distance\t\tIR raw value\r\n";
cyBOT_Scan_t scanData;

typedef struct{
    int position;
    float dist;
    int width;
}object_t;
object_t objects[5];

/*sound_dist = us sensor. IR_raw_val=ir sensor*/

int main(void){
    //resetSimulationBoard();
    timer_init();
    lcd_init();
    uart_init(115200);
    cyBOT_init_Scan();
    oi_t *sensor_data = oi_alloc();
    oi_init(sensor_data);
    while(1){
        if(flag){
            if(uart_data=='s'){
                sprintf(stringPrint, "\rAngle\t\tPING distance\t\tIR raw value\r\n");
                while(stringPrint[i]!=0){
                    uart_sendChar(stringPrint[i]);
                    i++;
                }
                i=0;
                lcd_printf("scan starting");
                for(angle=0;angle<=180;angle++){
                    cyBOT_Scan(angle,&scanData);
                    lcd_printf("scan occurred");
                    if(scanData.IR_raw_val>175){
                        startAngle=angle;
                        while((scanData.IR_raw_val>175)&&(angle<=180)){
                            distAvg+=scanData.sound_dist;
                            sprintf(stringPrint, "\r%d\t\t%f\t\t%d\r\n",angle,scanData.sound_dist,scanData.IR_raw_val);
                            while(stringPrint[i]!=0){
                                uart_sendChar(stringPrint[i]);
                                i++;
                            }
                            i=0;
                            cyBOT_Scan(angle,&scanData);
                            angle++;
                        }
                        endAngle=angle;
                        objects[objCount].width=endAngle-startAngle;
                        objects[objCount].position=angle-((endAngle-startAngle)/2);
                        objects[objCount].dist=(distAvg/(objects[objCount].width));
                        objCount++;
                        distAvg=0;
                    }
                    sprintf(stringPrint, "\r%d\t\t%f\t\t%d\r\n",angle,scanData.sound_dist,scanData.IR_raw_val);
                    while(stringPrint[i]!=0){
                        uart_sendChar(stringPrint[i]);
                        i++;
                    }
                i=0;
                }
            }
            flag=0;
            sprintf(stringPrint, "\rObject\t\tWidth\t\tPosition\tDistance\r\n");
            while(stringPrint[i]!=0){
                uart_sendChar(stringPrint[i]);
                i++;
            }
            i=0;
            smallObj=0;
            for(i=0;i<objCount;i++){
                if(objects[i].width<objects[smallObj].width){
                    smallObj=i;
                }
            }
            i=0;
            for(i=0;i<objCount;i++){
                sprintf(stringPrint, "\r%d\t\t%d\t\t%d\t\t%f\r\n",i+1,objects[i].width,objects[i].position,objects[i].dist);
                while(stringPrint[j]!=0){
                    uart_sendChar(stringPrint[j]);
                    j++;
                }
            j=0;
            }
            i=0;
            sprintf(stringPrint,"\rSmallest object is %d\r\n",smallObj+1);
            while(stringPrint[i]!=0){
                uart_sendChar(stringPrint[i]);
                i++;
            }
            i=0;

        }
    }
}
